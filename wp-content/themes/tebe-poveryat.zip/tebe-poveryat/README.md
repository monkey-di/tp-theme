# Tebe Poveryat (WordPress Theme)

**Tebe Poveryat** — это кастомная WordPress тема, разработанная с использованием гибридного подхода (Classic PHP + Tailwind CSS v4).

## 🛠 Технический стек

*   **WordPress:** Классическая структура шаблонов (`.php` файлы).
*   **Styling:** **Tailwind CSS v4** (Alpha/Beta). Конфигурация через CSS-переменные в `src/input.css`.
*   **Build Tool:** `npm` scripts + Tailwind CLI (или `./build.sh`).
*   **Fonts:** Geologica (Google Fonts), Akrobat (Local), Ura Bum Bum SP (Local).
*   **JS:** Ванильный JS (планируется подключение Swiper.js).

## 📂 Структура файлов

```text
tebe-poveryat/
├── assets/
│   ├── css/
│   │   └── output.css       # Скомпилированный CSS (подключается в WP)
│   ├── fonts/               # Локальные шрифты
│   └── js/                  # Скрипты (main.js, slider.js)
├── parts/                   # HTML-части для FSE (не используются в классике, но оставлены)
├── patterns/                # Старые паттерны блоков (могут быть удалены)
├── src/
│   └── input.css            # Исходный CSS и конфиг Tailwind (@theme)
├── template-parts/          # PHP-компоненты темы
│   ├── home/                # Секции главной страницы (Hero, About, etc.)
│   └── components/          # Переиспользуемые UI элементы (Button, Link, etc.)
├── footer.php               # Подвал сайта
├── front-page.php           # Шаблон главной страницы
├── functions.php            # Логика темы и подключение ассетов
├── header.php               # Шапка сайта
├── index.php                # Базовый шаблон
└── theme.json               # Настройки редактора блоков и палитра цветов
```

## 🚀 Разработка (Development)

Для работы с темой необходимо иметь установленный Node.js.

1.  **Установка зависимостей:**
    ```bash
    cd wp-content/themes/tebe-poveryat
    npm install
    ```

2.  **Запуск режима разработки (Watch):**
    В отдельном терминале запустите команду. Она будет следить за изменениями в PHP/HTML файлах и пересобирать CSS.
    ```bash
    npm run dev
    ```
    *Или используйте скрипт в корне проекта:* `./build.sh` (одноразовая сборка).

3.  **Работа с компонентами:**
    Мы используем `get_template_part` с аргументами.
    Пример вызова кнопки:
    ```php
    <?php get_template_part('template-parts/components/button', null, [
        'text' => 'Подробнее',
        'style' => 'primary', // primary, secondary, white, outline-white
        'url' => '/about'
    ]); ?>
    ```

## 🎨 Цветовая палитра (Tailwind)

Цвета настроены в `src/input.css` (секция `@theme`):

*   `primary`: `#6063a6` (Фиолетовый)
*   `secondary`: `#d98b99` (Розовый)
*   `base`: `#fef1ec` (Светло-песочный)
*   `teal`: `#1c5358` (Темно-зеленый)
*   `sky`: `#6bbad9` (Голубой)
*   `peach`: `#f2c995` (Персиковый)
*   `contrast`: `#1e1e1e` (Почти черный)

## 🧩 Компоненты (UI Kit)

Все UI-элементы находятся в `template-parts/components/`:

*   **`button.php`**: Универсальная кнопка/ссылка.
*   **`link-more.php`**: Ссылка "Читать далее" с иконкой стрелки и анимацией.
*   **`input-with-button.php`**: Поле ввода с кнопкой внутри (для подписки).
*   **`slider-progress.php`**: Индикатор прогресса слайдера.

---
*Разработано для фонда "Тебе поверят"*
