<?php
/**
 * Title: Секция О нас
 * Slug: tebe-poveryat/about
 * Categories: text
 * Description: Информация о проекте или организации.
 */
?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"60px","bottom":"60px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:60px;padding-bottom:60px">
    <!-- wp:heading -->
    <h2 class="wp-block-heading">О нас</h2>
    <!-- /wp:heading -->
    <!-- wp:paragraph -->
    <p>Краткое описание нашей деятельности и ценностей.</p>
    <!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
